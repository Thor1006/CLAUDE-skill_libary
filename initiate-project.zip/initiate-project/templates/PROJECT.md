# Project: {{name}}

<!-- Stable facts. Change rarely; log why in DECISIONS.md. -->

## What & why
{{1–3 sentences: what it is, who it's for, the problem it solves}}

## Goals
- {{v1 / milestone definition}}

## Non-goals
- {{things deliberately out of scope}}

## Stack
- {{language, framework, key libraries, runtime}}

## Architecture
{{3–8 lines: main parts and how they connect; key entry points as paths}}

## Key paths
- `{{path}}` — {{what lives there}}
