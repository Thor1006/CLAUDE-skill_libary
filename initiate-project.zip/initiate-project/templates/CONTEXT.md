# Context

<!-- Living state. Updated by /wrap-up at the end of every loop. Keep under ~40 lines: replace, don't append forever. -->

**Last updated:** {{YYYY-MM-DD}}

## Current focus
{{what we're working on right now}}

## Recent changes
- {{YYYY-MM-DD}} — {{what changed}} ([report](output/{{file}}.md))

## Open questions
- {{things waiting on a decision or info}}

## Next steps
1. {{concrete next move}}
