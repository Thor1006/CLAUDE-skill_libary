# {{Project name}} — Claude instructions

@PROJECT.md
@CONTEXT.md

## Commands
| Task | Command |
|------|---------|
| Install | {{cmd}} |
| Dev | {{cmd}} |
| Test | {{cmd}} |
| Lint/format | {{cmd}} |

## Session routine
1. **Start:** read `CLAUDE/CONTEXT.md`, run `git status -sb`, then post a short kickoff:
   `Goal:` · `Done means:` · `Plan:` (3–5 lines total).
2. **Before non-trivial work** (new feature, multi-file change, anything risky): write a proposal to `CLAUDE/plans/YYYY-MM-DD-<slug>.md` using `_TEMPLATE.md`, status `proposed`, and wait for OK. When a plan-mode plan is approved, copy it there with status `approved`.
3. **During:** one-line check-ins after each step. Verify before saying done.
4. **After each loop** (task finished or stopping point): run `/wrap-up` — report to `CLAUDE/output/`, update `CONTEXT.md`, log decisions in `DECISIONS.md`, set the plan's status to `done`.

## Conventions
- {{language / style / formatter}}
- {{test framework and where tests live}}
- {{folder layout notes}}

## Off-limits / ask first
- {{e.g. live API calls, deploys, deleting data, pushing to main}}

## Working with me
- Keep updates short.
- I'm on PowerShell 7: PowerShell syntax, one command per code block.
- I'm learning git: explain git commands in plain words; don't commit or push unless I ask.
