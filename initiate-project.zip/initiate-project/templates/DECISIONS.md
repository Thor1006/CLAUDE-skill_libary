# Decisions

<!-- Newest on top. One short entry per decision that someone might later ask "why did we do it this way?" about. -->

## {{YYYY-MM-DD}} — {{decision title}}
- **Decision:** {{what we chose}}
- **Why:** {{reason}}
- **Alternatives:** {{what we didn't pick, and why not}}
