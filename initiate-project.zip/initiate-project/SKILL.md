---
name: initiate-project
description: One-time project setup, like /init but fuller — scans the code (or interviews for an empty folder) and creates a visible CLAUDE/ workspace (CLAUDE.md, PROJECT.md, CONTEXT.md, DECISIONS.md, output/ reports, plans/ proposals) plus .claude/ config and a project /wrap-up command. Use when the user types /initiate-project or asks to set up / initialize / bootstrap a project for Claude.
---

# Initiate Project

Set up a project so every future Claude session starts oriented and leaves a trail. Run once per project. Templates live in `templates/` next to this file — read each one before filling it in.

## What gets created

```
<project>/
  CLAUDE.md                 ← one line: @CLAUDE/CLAUDE.md  (auto-loaded by Claude Code)
  CLAUDE/
    CLAUDE.md               ← templates/CLAUDE.md
    PROJECT.md              ← templates/PROJECT.md
    CONTEXT.md              ← templates/CONTEXT.md
    DECISIONS.md            ← templates/DECISIONS.md
    output/_TEMPLATE.md     ← templates/report.md
    plans/_TEMPLATE.md      ← templates/plan.md
  .claude/
    skills/wrap-up/SKILL.md ← templates/wrap-up-SKILL.md
    settings.json           ← built in step 5
    launch.json             ← only if a dev server was found
```

## Workflow

### 1. Detect (read-only, no narration)
- Empty folder or existing code? (Ignore `.git`, `.claude`, `.vscode`, OS junk when deciding.)
- Git repo? Run `git status -sb` if so.
- Existing root `CLAUDE.md`, `CLAUDE/` folder, or `.claude/` files? Note them — they must not be clobbered.
- If `CLAUDE/PROJECT.md` already exists, the project was already initiated: say so and ask whether to refresh it or stop.

### 2. Scan (existing code only)
Read, don't guess:
- Manifests: `package.json`, `pyproject.toml`, `requirements.txt`, `Cargo.toml`, `go.mod`, `*.csproj`, `pom.xml`, etc.
- `README*`, existing docs, CI config (`.github/workflows/`).
- Top two levels of the folder tree (skip `node_modules`, `.venv`, `dist`, `build`).
- Commands for install / dev / build / test / lint — from scripts sections, Makefiles, READMEs.
- A dev server and its port, if any (for launch.json).
- Conventions visible in the code: language, formatter, test framework, folder layout.

Use an Explore subagent only if the repo is large; otherwise scan inline.

### 3. Interview (1–2 AskUserQuestion rounds, max 4 questions each)
Ask only what the scan couldn't answer:
- What is this project for / who uses it? What does "done" or "v1" look like?
- Anything off-limits (files, services, live API calls, deploys)?
- How do you like to work? (e.g. plan before code, how often to report, commit style)
- **Empty folder only:** tech stack, and what the first milestone is.

### 4. Preview and confirm
Show the file tree from above (only the parts that will actually be created) plus a 3–5 line summary of what PROJECT.md will say. Mention anything existing that will be moved or merged. Wait for an OK.

### 5. Write
Fill each template with real findings — no leftover `{{placeholders}}`; write "unknown — ask" for things you don't know.

- **Root `CLAUDE.md`:**
  - None exists → write the single line `@CLAUDE/CLAUDE.md`.
  - One exists → with the user's OK, move its content into `CLAUDE/CLAUDE.md` under a `## Carried over from the old CLAUDE.md` heading, then replace the root file with the pointer line.
- **`.claude/settings.json`:** if it exists, merge — never drop existing keys. Add read-only allows only, e.g.:
  ```json
  { "permissions": { "allow": ["Bash(git status:*)", "Bash(git log:*)", "Bash(git diff:*)", "PowerShell(git status*)", "PowerShell(git log*)", "PowerShell(git diff*)"] } }
  ```
  plus the project's test/lint commands found in the scan. Nothing that writes, pushes, deletes, or installs.
- **`.claude/launch.json`:** only if a dev server was found:
  ```json
  { "version": "0.0.1", "configurations": [ { "name": "<name>", "runtimeExecutable": "<npm|python|...>", "runtimeArgs": ["..."], "port": 0 } ] }
  ```
- **CONTEXT.md:** seed "Current focus" with the goal from the interview and "Next steps" with 1–3 concrete first moves.
- **DECISIONS.md:** add a first entry: "Adopted CLAUDE/ workspace via /initiate-project".

### 6. Empty folder extras (ask first)
Offer, with a one-line explanation of each:
- `git init` — "starts tracking versions of your files in this folder".
- A `.gitignore` suited to the chosen stack.
Run only what the user agrees to. Do not commit unless asked.

### 7. Finish
Post a short summary:
```
## Project initiated
**Created:** <file list as links>
**How it works:** each session reads CONTEXT.md → work → `/wrap-up` writes a report to CLAUDE/output/ and updates CONTEXT.md.
**Proposals:** go in CLAUDE/plans/ before big changes.
**Next:** <first step from CONTEXT.md>
```
Note that `/wrap-up` becomes available after reopening the session.

## Rules
- Never overwrite an existing file without showing what changes and getting an OK.
- Keep generated files short — they're loaded into every session, so every line costs context.
- User is on PowerShell 7 and learning git: give PowerShell syntax, one command per code block, and explain git commands in plain words.
